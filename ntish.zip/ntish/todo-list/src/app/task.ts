export class TASK
{
    id:number;
    name:string;
    completed:any;
    editing:any;

}